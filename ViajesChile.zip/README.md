# Viajes Chile

Esta es una maqueta de una p�gina web de Turismo en Chile. Se desarroll� como prueba para el final de m�dulo 2 Front-End del curso Fullstack Python Trainee, dictado en la OTEC Edutecno.

## C�mo se visualiza

Para ver la p�gina web, puedes acceder desde el siguiente enlace: https://spy0x.github.io/Viajes-Chile/

## Detalles
Desarrollado con HTML5, CSS y Javascript. 

Se utiliz�: 
Bootstrap v5.1.3
Jquery v3.6.0
Google Fonts API
Fontawesome v5.15.4

## Licencia

Proyecto exclusivamente desarrollado con fines acad�micos para la OTEC Edutecno, Chile.